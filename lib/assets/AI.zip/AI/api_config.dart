class APIConfig {
  // Replace with your actual API key
  static const String openAIApiKey = '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';
  
  // Add fallback responses for when API is unavailable
  static const List<String> fallbackResponses = [
    'I apologize, but I\'m currently unavailable. Please try again later.',
    'Our system is experiencing high demand. Please try again in a few minutes.',
    'I\'m unable to process your request right now. Please contact support if this persists.',
  ];
}